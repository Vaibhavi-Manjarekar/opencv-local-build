#pragma once

#include <cstdint>

namespace cv {
namespace dnn {

void flop_counter_start();
void flop_counter_increment(std::uint64_t count);
std::uint64_t flop_counter_stop();

} // namespace dnn
} // namespace cv