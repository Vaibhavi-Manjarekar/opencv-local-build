#include "flop_counter.hpp"

namespace cv {
namespace dnn {
namespace {

thread_local std::uint64_t currentFlops = 0;
thread_local bool counterEnabled = false;

} 

void flop_counter_start()
{
    currentFlops = 0;
    counterEnabled = true;
}

void flop_counter_increment(std::uint64_t count)
{
    if (counterEnabled)
        currentFlops += count;
}

std::uint64_t flop_counter_stop()
{
    counterEnabled = false;
    return currentFlops;
}

} 
} 